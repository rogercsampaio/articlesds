# script
# 1 - criando a matriz
# Parâmetros:
# matrix = palavra reservada e obrigatória para criar matrizes
# data = os valores da matriz, c representa um conjunto de valores em forma de vetor
# nrow = número de linhas da matriz
# ncol = número de colunas da matriz
matrixRemuneracaoFunc <- matrix(data = c(1200,1300,1500,2000,0,100,300,500),
                                nrow = 4,ncol = 2)
# exibindo a matriz
matrixRemuneracaoFunc
# acessando o M(2,1)
matrixRemuneracaoFunc[2,1]
# gerando nova matriz, o comando da linha abaixo considera cada linha da matriz
# e através do método SUM, faz a soma
matrixResultado <- matrix(apply(matrixRemuneracaoFunc[, 1:2], 1, sum))
# exibindo a matriz resultado
matrixResultado

# transporta da matrixResultado através da função t()
matrixTransporta <- t(matrixResultado)
matrixTransporta

# calculando a média aritmética usando a função mean
mean(matrixTransporta)
# calculando o valor máximo e minimo
min(matrixTransporta)
max(matrixTransporta)